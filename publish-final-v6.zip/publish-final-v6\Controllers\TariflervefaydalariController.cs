﻿using Microsoft.AspNetCore.Mvc;

namespace MyGoldenFood.Controllers
{
    public class TariflervefaydalariController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
