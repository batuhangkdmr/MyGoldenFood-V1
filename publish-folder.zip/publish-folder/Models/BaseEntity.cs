﻿namespace MyGoldenFood.Models
{
    public class BaseEntity
    {
        public int Id { get; set; }
    }
}
