﻿using Microsoft.EntityFrameworkCore;
using MyGoldenFood.Models;
using System.Linq;

namespace MyGoldenFood.ApplicationDbContext
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        // Lazy Loading Proxy ayarı - Canlı ortamda devre dışı
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // Lazy loading sadece development ortamında aktif
                // optionsBuilder.UseLazyLoadingProxies();
            }
        }

        // Model yapılandırmaları
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Varsayılan String uzunluğu
            foreach (var entityType in modelBuilder.Model.GetEntityTypes())
            {
                var properties = entityType.GetProperties()
                    .Where(p => p.ClrType == typeof(string));

                foreach (var property in properties)
                {
                    property.SetMaxLength(255); // Varsayılan String uzunluğu
                }
            }

            // 📌 RecipeCategoryTranslation ile RecipeCategory ilişkisi
            modelBuilder.Entity<RecipeCategoryTranslation>()
                .ToTable("RecipeCategoryTranslations") // Tek seferde ayarla
                .HasOne(rct => rct.RecipeCategory)
                .WithMany(rc => rc.Translations) // `RecipeCategory` içinde `Translations` koleksiyonu olmalı!
                .HasForeignKey(rct => rct.RecipeCategoryId)
                .OnDelete(DeleteBehavior.Cascade);

            // 📌 BenefitCategoryTranslation ile BenefitCategory ilişkisi
            modelBuilder.Entity<BenefitCategoryTranslation>()
                .ToTable("BenefitCategoryTranslations")
                .HasOne(bct => bct.BenefitCategory)
                .WithMany(bc => bc.Translations)
                .HasForeignKey(bct => bct.BenefitCategoryId)
                .OnDelete(DeleteBehavior.Cascade);

            // 📌 Benefit ile BenefitCategory ilişkisi
            modelBuilder.Entity<Benefit>()
                .HasOne(b => b.BenefitCategory)
                .WithMany(bc => bc.Benefits)
                .HasForeignKey(b => b.BenefitCategoryId)
                .OnDelete(DeleteBehavior.SetNull); // Kategori silinirse fayda kategorisiz kalsın

            // 📌 Tabloları Ayarla
            modelBuilder.Entity<Product>().ToTable("Products");
            modelBuilder.Entity<User>().ToTable("Users");
            modelBuilder.Entity<Recipe>().ToTable("Recipes"); // Tarif tablosu
            modelBuilder.Entity<Benefit>().ToTable("Benefits"); // Fayda tablosu
            modelBuilder.Entity<Blog>().ToTable("Blogs"); // Blog tablosu
            modelBuilder.Entity<ProductTranslation>().ToTable("ProductTranslations");
            modelBuilder.Entity<RecipeTranslation>().ToTable("RecipeTranslations");
            modelBuilder.Entity<BenefitTranslation>().ToTable("BenefitTranslations");
            modelBuilder.Entity<RecipeCategory>().ToTable("RecipeCategories"); // Tarif kategorileri tablosu
            modelBuilder.Entity<BenefitCategory>().ToTable("BenefitCategories"); // Fayda kategorileri tablosu
            modelBuilder.Entity<BenefitCategoryTranslation>().ToTable("BenefitCategoryTranslations"); // Fayda kategori çevirileri tablosu

            base.OnModelCreating(modelBuilder);
        }

        // 📌 Veritabanı Tabloları
        public DbSet<Product> Products { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<RecipeCategory> RecipeCategories { get; set; } // Tarif kategorileri
        public DbSet<RecipeCategoryTranslation> RecipeCategoryTranslations { get; set; } // Tarif kategori çevirileri
        public DbSet<Recipe> Recipes { get; set; } // Tarifler
        public DbSet<BenefitCategory> BenefitCategories { get; set; } // Fayda kategorileri
        public DbSet<BenefitCategoryTranslation> BenefitCategoryTranslations { get; set; } // Fayda kategori çevirileri
        public DbSet<Benefit> Benefits { get; set; } // Faydalar
        public DbSet<Blog> Blogs { get; set; } // Blog yazıları
        public DbSet<ProductTranslation> ProductTranslations { get; set; }
        public DbSet<RecipeTranslation> RecipeTranslations { get; set; }
        public DbSet<BenefitTranslation> BenefitTranslations { get; set; }

        // `Translation` kullanılmıyorsa bunu kaldırabilirsin
        public DbSet<Translation> Translations { get; set; }
    }
}
