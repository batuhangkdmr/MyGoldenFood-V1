using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Localization;
using System.Globalization;
using CloudinaryDotNet;
using CloudinaryDotNet.Actions;
using Microsoft.EntityFrameworkCore;
using MyGoldenFood.ApplicationDbContext;
using MyGoldenFood.Services;
using System.Net;
using System.Net.Mail;
using MyGoldenFood.Hubs;

namespace MyGoldenFood
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }

    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            // 🌐 Localization: Çoklu dil desteği
            services.AddLocalization(options => options.ResourcesPath = "Resources");

            var supportedCultures = new[]
            {
                new CultureInfo("tr"),  // Türkçe (Varsayılan)
                new CultureInfo("en"),  // İngilizce
                new CultureInfo("de"),  // Almanca
                new CultureInfo("fr"),  // Fransızca
                new CultureInfo("ru"),  // Rusça
                new CultureInfo("ja"),  // Japonca
                new CultureInfo("ko"),  // Korece
                new CultureInfo("ar")   // Arapça
            };

            // 🌐 Localization yapılandırmasını DI üzerinden veriyoruz
            services.Configure<RequestLocalizationOptions>(options =>
            {
                options.DefaultRequestCulture = new RequestCulture("tr");
                options.SupportedCultures = supportedCultures;
                options.SupportedUICultures = supportedCultures;

                // İsteğe göre kültürü URL'den belirlemeye izin ver
                options.RequestCultureProviders.Insert(0, new QueryStringRequestCultureProvider());
            });

            // 🌐 MVC'de localization aktif
            services.AddControllersWithViews()
                .AddViewLocalization()
                .AddDataAnnotationsLocalization();

            // 🌐 Cloudinary Servisi
            services.AddSingleton(sp =>
            {
                var cloudinaryConfig = Configuration.GetSection("CloudinarySettings");
                var account = new Account(
                    cloudinaryConfig["CloudName"],
                    cloudinaryConfig["ApiKey"],
                    cloudinaryConfig["ApiSecret"]
                );
                return new Cloudinary(account);
            });

            // 💼 DI Container Kayıtları
            services.AddScoped<CloudinaryService>();
            services.AddScoped<DeepLTranslationService>();
            services.AddScoped<MailService>();
            services.AddScoped<LocalizationCacheService>();
            services.AddScoped<TranslationService>();

            // 💾 DB Ayarı
            services.AddDbContext<AppDbContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

            // 🔐 Authentication
            services.AddAuthentication("AdminCookie")
                .AddCookie("AdminCookie", options =>
                {
                    options.LoginPath = "/Admin/Index";
                    options.AccessDeniedPath = "/Admin/Index";
                });

            // 📧 Mail Ayarları
            var emailSettings = Configuration.GetSection("EmailSettings");
            services.AddScoped<SmtpClient>(sp =>
            {
                return new SmtpClient(emailSettings["SmtpServer"], int.Parse(emailSettings["Port"]))
                {
                    Credentials = new NetworkCredential(emailSettings["Username"], emailSettings["Password"]),
                    EnableSsl = true
                };
            });

            // 🧠 Memory Cache
            services.AddMemoryCache();

            // 📡 SignalR
            services.AddSignalR();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            // 🌐 Localization Middleware Aktifleştir
            var locOptions = app.ApplicationServices.GetService<IOptions<RequestLocalizationOptions>>();
            app.UseRequestLocalization(locOptions.Value);

            // ⚠️ Hata Ayarları
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            // 📡 SignalR Hub'ları
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHub<ProductHub>("/productHub");
                endpoints.MapHub<FaydalariHub>("/faydalariHub");
                endpoints.MapHub<TariflerHub>("/tariflerHub");

                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
